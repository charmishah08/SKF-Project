﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace SKF.Admin
{
    public partial class Report_Fees : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindClassLevel();                               
            }
        }

      
        public void BindData()
        {
            sqlstmt = "";
            sqlstmt = "SELECT student_master.stu_id, student_master.stu_fname, student_master.stu_lname, fees_master.fees_amount, fees_history.fees_paid_date, fees_master.fees_due_date FROM student_master INNER JOIN enroll_master ON enroll_master.enroll_student_id = student_master.stu_id INNER JOIN fees_history ON student_master.stu_id = fees_history.fees_stu_id INNER JOIN fees_master ON fees_history.fees_id = fees_master.fees_id WHERE enroll_master.enroll_student_id = " + DropClassLevel.SelectedValue;
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Lst_Fees_Report.Visible = true;
                Lst_Fees_Report.DataSource = ds.Tables[0];
                Lst_Fees_Report.DataBind();
            }
            else
            {
                Lst_Fees_Report.DataSource = null;
                Lst_Fees_Report.Visible = false;
            }
        }

        public void BindData1()
        {
            if (DropFees.SelectedValue == "DUE")
            {
                sqlstmt = "";
                sqlstmt = "SELECT student_master.stu_id, student_master.stu_fname, student_master.stu_lname, fees_master.fees_amount, fees_history.fees_paid_date, fees_master.fees_due_date FROM student_master INNER JOIN enroll_master ON enroll_master.enroll_student_id = student_master.stu_id INNER JOIN fees_history ON student_master.stu_id = fees_history.fees_stu_id INNER JOIN fees_master ON fees_history.fees_id = fees_master.fees_id WHERE enroll_master.enroll_student_id = " + DropClassLevel.SelectedValue + " AND fees_history.fees_paid_date >= fees_master.fees_due_date";
                DataSet ds = cls.Select(sqlstmt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Lst_Fees_Report.Visible = true;
                    Lst_Fees_Report.DataSource = ds.Tables[0];
                    Lst_Fees_Report.DataBind();
                }
                else
                {
                    Lst_Fees_Report.DataSource = null;
                    Lst_Fees_Report.Visible = false;
                }
            }
            else if(DropFees.SelectedValue == "PAID")
            {
                sqlstmt = "";
                sqlstmt = "SELECT student_master.stu_id, student_master.stu_fname, student_master.stu_lname, fees_master.fees_amount, fees_history.fees_paid_date, fees_master.fees_due_date FROM student_master INNER JOIN enroll_master ON enroll_master.enroll_student_id = student_master.stu_id INNER JOIN fees_history ON student_master.stu_id = fees_history.fees_stu_id INNER JOIN fees_master ON fees_history.fees_id = fees_master.fees_id WHERE enroll_master.enroll_student_id = " + DropClassLevel.SelectedValue + " AND fees_history.fees_paid_date <= fees_master.fees_due_date";
                DataSet ds = cls.Select(sqlstmt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    Lst_Fees_Report.Visible = true;
                    Lst_Fees_Report.DataSource = ds.Tables[0];
                    Lst_Fees_Report.DataBind();
                }
                else
                {
                    Lst_Fees_Report.DataSource = null;
                    Lst_Fees_Report.Visible = false;
                }
            }
            
        }

        
        public void BindClassLevel()
        {
            sqlstmt = "";
            sqlstmt = "Select * from class_level_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropClassLevel.DataSource = ds.Tables[0];
                DropClassLevel.DataTextField = "class_level";
                DropClassLevel.DataValueField = "class_level_id";
                DropClassLevel.DataBind();
            }
            else
            {
                DropClassLevel.DataSource = System.DBNull.Value.ToString();
                DropClassLevel.DataBind();
            }
            DropClassLevel.Items.Insert(0, "--Select--");
        }
                
                        
        protected void DropClassLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindData();
        }

        protected void DropFees_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindData1();            
        }
    }
}