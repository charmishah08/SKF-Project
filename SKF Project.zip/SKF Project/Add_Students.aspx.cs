﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace SKF.Admin
{
    public partial class Add_Students : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";
        string sqlstmt1 = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //BindSchool();
                var unique_id = Request.QueryString["id"];
                if (unique_id != null)
                {
                    GetData();
                }
            }
        }

        //public void BindSchool()
        //{
        //    sqlstmt = "";
        //    sqlstmt = "Select * from school_master";
        //    DataSet ds = cls.Select(sqlstmt);
        //    if (ds.Tables[0].Rows.Count > 0)
        //    {
        //        DropSchooName.DataSource = ds.Tables[0];
        //        DropSchooName.DataTextField = "school_name";
        //        DropSchooName.DataValueField = "school_id";
        //        DropSchooName.DataBind();
        //    }
        //    else
        //    {
        //        DropSchooName.DataSource = System.DBNull.Value.ToString();
        //        DropSchooName.DataBind();
        //    }
        //    DropSchooName.Items.Insert(0, "--Select--");
        //}

        public void GetData()
        {
            var unique_id = Request.QueryString["id"];
            sqlstmt = "";
            sqlstmt = "SELECT stu_id,stu_fname,stu_mname,stu_lname,stu_email,stu_phone,DATE_FORMAT(stu_dob,'%Y-%m-%d') AS stu_dob,DATE_FORMAT(stu_join_date,'%Y-%m-%d') AS stu_join_date,stu_is_active,addr_id,addr_city,addr_state,addr_country,addr_zip,addr_stu_id FROM student_master INNER JOIN address_master ON student_master.stu_id = address_master.addr_stu_id where stu_id = " + unique_id.ToString();
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtStuFName.Text = ds.Tables[0].Rows[0]["stu_fname"].ToString();
                txtStuMName.Text = ds.Tables[0].Rows[0]["stu_mname"].ToString();
                txtStuLName.Text = ds.Tables[0].Rows[0]["stu_lname"].ToString();
                txtStuEmail.Text = ds.Tables[0].Rows[0]["stu_email"].ToString();
                txtStuPhone.Text = ds.Tables[0].Rows[0]["stu_phone"].ToString();
                Drop_city.SelectedValue = ds.Tables[0].Rows[0]["addr_city"].ToString();
                Drop_state.SelectedValue = ds.Tables[0].Rows[0]["addr_state"].ToString();
                Drop_country.SelectedValue = ds.Tables[0].Rows[0]["addr_country"].ToString();
                txtaddrZip.Text = ds.Tables[0].Rows[0]["addr_zip"].ToString();
                txtStuDOB.Value = ds.Tables[0].Rows[0]["stu_dob"].ToString();
                txtStuDOJ.Value = ds.Tables[0].Rows[0]["stu_join_date"].ToString();
            }
        }

        public void CrudOP()
        {
            var unique_id = Request.QueryString["id"];
            if (unique_id == null)
            {
                sqlstmt = "";
                sqlstmt = "Insert into student_master (stu_fname,stu_mname,stu_lname,stu_email,stu_phone,stu_dob,stu_join_date,stu_is_active) values ('" + txtStuFName.Text.Trim() + "','" + txtStuMName.Text.Trim() + "','" + txtStuLName.Text.Trim() + "','" + txtStuEmail.Text.Trim() +"','"+ txtStuPhone.Text.Trim() +"','"+ txtStuDOB.Value.Trim() + "','"+ txtStuDOJ.Value.Trim() +"','Active') ";
                cls.Insert(sqlstmt);

                string dt = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
                string cdt = DateTime.Now.ToString("yyyy-MM-dd");
                string Password = CreateRandomNumber(8);
                sqlstmt = "Insert into login_master (login_uname,login_password,login_datetime,login_usertype) values ('" + txtStuEmail.Text.Trim() + "','" + Password.ToString() + "','" + dt.ToString().Trim() + "','2') ";
                cls.Insert(sqlstmt);               

                sqlstmt1 = "";
                sqlstmt1 = "Select MAX(stu_id) as stu_id from student_master";
                DataSet ds = cls.Select(sqlstmt1);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    string stu_id = ds.Tables[0].Rows[0]["stu_id"].ToString();
                    sqlstmt = "";
                    sqlstmt = "Insert into address_master (addr_stu_id,addr_city,addr_state,addr_country,addr_zip) values ('" + stu_id.ToString().Trim() + "','" + Drop_city.SelectedValue.Trim() + "','" + Drop_state.SelectedValue.Trim() + "','" + Drop_country.SelectedValue.Trim() + "','" + txtaddrZip.Text.Trim() + "') ";
                    cls.Insert(sqlstmt);
                    sqlstmt = "Insert into rank_history (rank_type_id,rank_stu_id,rank_date) values ('1','" + stu_id.ToString().Trim() +"','" + cdt.ToString().Trim() + "') ";
                    cls.Insert(sqlstmt);
                }

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Inserted..!')", true);
                Response.Redirect("Students.aspx");
                //ShowMessageBox("Activities.aspx","Record Inserted..!");    
            }
            else
            {
                sqlstmt = "";
                sqlstmt = "Update student_master set stu_fname = '"+ txtStuFName.Text.Trim() + "',stu_mname = '" + txtStuMName.Text.Trim() + "',stu_lname = '" + txtStuLName.Text.Trim() + "',stu_phone = '" + txtStuPhone.Text.Trim() + "',stu_dob = '" + txtStuDOB.Value.Trim() + "',stu_join_date = '" + txtStuDOJ.Value.Trim() + "' where stu_id =" + unique_id.ToString();
                cls.Update(sqlstmt);
                sqlstmt = "Update address_master set addr_city = '" + Drop_city.SelectedValue.Trim() + "',addr_state = '" + Drop_state.SelectedValue.Trim() + "',addr_country = '" + Drop_country.SelectedValue.Trim() + "',addr_zip = '" + txtaddrZip.Text.Trim() + "' where addr_stu_id =" + unique_id.ToString();
                cls.Update(sqlstmt);

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Updated..!')", true);
                Response.Redirect("Students.aspx");
                //ShowMessageBox("Activities.aspx", "Record Updated..!");
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            CrudOP();
        }

        public static string CreateRandomNumber(int PasswordLength)
        {
            string _allowedChars = "0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ";
            Random randNum = new Random();
            char[] chars = new char[PasswordLength];
            int allowedCharCount = _allowedChars.Length;
            for (int i = 0; i < PasswordLength; i++)
            {
                chars[i] = _allowedChars[(int)((_allowedChars.Length) * randNum.NextDouble())];
            }
            return new string(chars);
        }
    }
}