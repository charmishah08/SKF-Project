﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace SKF.Admin
{
    public partial class Add_Activities : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                BindClassLevel();
                var unique_id = Request.QueryString["id"];
                if (unique_id != null)
                {
                    GetData();
                }
            }
        }

        public void BindClassLevel()
        {
            sqlstmt = "";
            sqlstmt = "Select * from class_level_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropClassLevel.DataSource = ds.Tables[0];
                DropClassLevel.DataTextField = "class_level";
                DropClassLevel.DataValueField = "class_level_id";
                DropClassLevel.DataBind();
            }
            else
            {
                DropClassLevel.DataSource = System.DBNull.Value.ToString();
                DropClassLevel.DataBind();
            }
            DropClassLevel.Items.Insert(0, "--Select--");
        }

        public void GetData()
        {
            var unique_id = Request.QueryString["id"];
            sqlstmt = "";
            sqlstmt = "SELECT class_level_master.class_level, class_level_master.class_level_id, activity_master.activity_name, activity_master.activity_description, DATE_FORMAT(activity_startdate,'%Y-%m-%d') AS activity_startdate, DATE_FORMAT(activity_enddate,'%Y-%m-%d') AS activity_enddate FROM activity_master INNER JOIN class_level_master ON activity_master.activity_class_level_id = class_level_master.class_level_id where activity_id = " + unique_id.ToString();
            DataSet ds = cls.Select(sqlstmt);
            if(ds.Tables[0].Rows.Count > 0)
            {
                DropClassLevel.SelectedValue = ds.Tables[0].Rows[0]["class_level_id"].ToString();
                txtActivity_Name.Text = ds.Tables[0].Rows[0]["activity_name"].ToString();
                txtActivity_Info.Text = ds.Tables[0].Rows[0]["activity_description"].ToString();
                txtStartdate.Text = ds.Tables[0].Rows[0]["activity_startdate"].ToString();
                txtenddate.Text = ds.Tables[0].Rows[0]["activity_enddate"].ToString();
            }
        }
        public void CrudOP()
        {
            var unique_id = Request.QueryString["id"];
            if(unique_id == null)
            {
                sqlstmt = "";
                sqlstmt = "Insert into activity_master (activity_class_level_id,activity_name,activity_description,activity_startdate,activity_enddate) values ('" + DropClassLevel.SelectedValue.Trim() + "','" + txtActivity_Name.Text.Trim() +"','"+ txtActivity_Info.Text.Trim() + "','" + txtStartdate.Text.Trim() + "','" + txtenddate.Text.Trim() + "')";
                cls.Insert(sqlstmt);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Inserted..!')", true);
                Response.Redirect("Activities.aspx");
                //ShowMessageBox("Activities.aspx","Record Inserted..!");    
            }
            else
            {
                sqlstmt = "";
                sqlstmt = "Update activity_master set activity_class_level_id = '" + DropClassLevel.SelectedValue.Trim() + "',activity_name = '" + txtActivity_Name.Text.Trim() + "', activity_description = '"+ txtActivity_Info.Text.Trim() + "', activity_startdate = '" + txtStartdate.Text.Trim() + "', activity_enddate = '" + txtenddate.Text.Trim() + "' where activity_id = " + unique_id.ToString();
                cls.Update(sqlstmt);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Updated..!')", true);
                Response.Redirect("Activities.aspx");
                //ShowMessageBox("Activities.aspx", "Record Updated..!");
            }
        }
        private void ShowMessageBox(string sURL, string mSG)
        {
            string sJavaScript = "<script language=javascript>\n";
            sJavaScript += "agree = confirm("+ mSG +"); \n";
            sJavaScript += "if(agree)\n";
            sJavaScript += "window.location = \"" + sURL + "\";\n";
            sJavaScript += "</script>";
            Response.Write(sJavaScript);
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            CrudOP();
        }
    }
}