﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace SKF.Admin
{
    public partial class Add_Activity_Fees : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindClassLevel();
                BindFeesType();
                var unique_id = Request.QueryString["id"];
                if (unique_id != null)
                {
                    GetData();
                }
            }
        }
        public void BindClassLevel()
        {
            sqlstmt = "";
            sqlstmt = "Select * from class_level_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropClassLevel.DataSource = ds.Tables[0];
                DropClassLevel.DataTextField = "class_level";
                DropClassLevel.DataValueField = "class_level_id";
                DropClassLevel.DataBind();
            }
            else
            {
                DropClassLevel.DataSource = System.DBNull.Value.ToString();
                DropClassLevel.DataBind();
            }
            DropClassLevel.Items.Insert(0, "--Select--");
        }

        public void BindFeesType()
        {
            sqlstmt = "";
            sqlstmt = "Select * from fees_type_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropDownType.DataSource = ds.Tables[0];
                DropDownType.DataTextField = "fees_type_name";
                DropDownType.DataValueField = "fees_type_id";
                DropDownType.DataBind();
            }
            else
            {
                DropDownType.DataSource = System.DBNull.Value.ToString();
                DropDownType.DataBind();
            }
            DropDownType.Items.Insert(0, "--Select--");
        }
        public void GetData()
        {
            var unique_id = Request.QueryString["id"];
            if (unique_id != null)
            {
                sqlstmt = "";
                sqlstmt = "SELECT * FROM fees_master INNER JOIN fees_type_master ON fees_master.fees_type_id = fees_type_master.fees_type_id INNER JOIN class_level_master ON fees_master.fees_class_level_id = class_level_master.class_level_id WHERE fees_master.fees_id =" + unique_id.ToString();

                DataSet ds = cls.Select(sqlstmt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DropClassLevel.SelectedValue = ds.Tables[0].Rows[0]["fees_class_level_id"].ToString();
                    DropDownType.SelectedValue = ds.Tables[0].Rows[0]["fees_type_id"].ToString();
                    txt_amount.Text = ds.Tables[0].Rows[0]["fees_amount"].ToString();
                    //txt_date.Text = ds.Tables[0].Rows[0]["fees_due_date"].ToString();
                }
            }

        }

        public void CrudOP()
        {
            var unique_id = Request.QueryString["id"];
            if (unique_id == null)
            {
                sqlstmt = "";
                sqlstmt = "SELECT * FROM class_level_master where class_level_id = " + DropClassLevel.SelectedValue;
                DataSet ds1 = cls.Select(sqlstmt);
                if (ds1.Tables[0].Rows.Count > 0)
                {
                       string class_start_date = ds1.Tables[0].Rows[0]["class_start_date"].ToString();
                       DateTime start_date = Convert.ToDateTime(class_start_date.ToString());
                       var Date = start_date.AddDays(30);
                       string newDate = Date.ToString("yyyy-MM-dd"); 
                       sqlstmt = "Insert into fees_master (fees_class_level_id,fees_type_id,fees_amount,fees_due_date) values ('" + DropClassLevel.SelectedValue.Trim() + "','" + DropDownType.SelectedValue.Trim() + "','" + txt_amount.Text.Trim() + "','" + newDate.ToString() + "')";
                       cls.Insert(sqlstmt);
                       ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Inserted..!')", true);
                       Response.Redirect("Activity_Fees.aspx");
                }
                                       
            }
            else
            {
                sqlstmt = "";
                sqlstmt = "SELECT * FROM class_level_master where class_level_id = " + DropClassLevel.SelectedValue;
                DataSet ds1 = cls.Select(sqlstmt);
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    string class_start_date = ds1.Tables[0].Rows[0]["class_start_date"].ToString();
                    DateTime start_date = Convert.ToDateTime(class_start_date.ToString());
                    var Date = start_date.AddDays(-15);
                    string newDate = Date.ToString("yyyy-MM-dd");
                    sqlstmt = "Update fees_master set fees_class_level_id = '" + DropClassLevel.SelectedValue.Trim() + "', fees_type_id = '" + DropDownType.SelectedValue.Trim() + "', fees_amount = '" + txt_amount.Text.Trim() + "' , fees_due_date = '" + newDate.ToString() + "' where fees_id = " + unique_id.ToString();
                    cls.Update(sqlstmt);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Updated..!')", true);
                    Response.Redirect("Activity_Fees.aspx");
                }
            }
        }
        private void ShowMessageBox(string sURL, string mSG)
        {
            string sJavaScript = "<script language=javascript>\n";
            sJavaScript += "agree = confirm(" + mSG + "); \n";
            sJavaScript += "if(agree)\n";
            sJavaScript += "window.location = \"" + sURL + "\";\n";
            sJavaScript += "</script>";
            Response.Write(sJavaScript);
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            CrudOP();
        }
    }
}