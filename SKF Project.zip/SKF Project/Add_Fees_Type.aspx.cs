﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace SKF.Admin
{
    public partial class Add_Fees : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                
                var unique_id = Request.QueryString["id"];
                if (unique_id != null)
                {
                    GetData();
                }
            }
        }

        
        public void GetData()
        {
            var unique_id = Request.QueryString["id"];
            sqlstmt = "";
            sqlstmt = "SELECT * FROM fees_type_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtfeestype.Text = ds.Tables[0].Rows[0]["fees_type_name"].ToString();
            }
        }

        public void CrudOP()
        {
            var unique_id = Request.QueryString["id"];
            if (unique_id == null)
            {
                sqlstmt = "";
                sqlstmt = "Insert into fees_type_master (fees_type_name) values ('" + txtfeestype.Text + "')";
                cls.Insert(sqlstmt);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Inserted..!')", true);
                Response.Redirect("Fees_Type.aspx");
                //ShowMessageBox("Activities.aspx","Record Inserted..!");    
            }
            else
            {
                sqlstmt = "";
                sqlstmt = "Update fees_type_master set fees_type_name = '" + txtfeestype.Text.Trim() + "' where fees_type_id =" + unique_id.ToString();
                cls.Update(sqlstmt);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Updated..!')", true);
                Response.Redirect("Fees_Type.aspx");
                //ShowMessageBox("Activities.aspx", "Record Updated..!");
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            CrudOP();
        }
                
    }
}