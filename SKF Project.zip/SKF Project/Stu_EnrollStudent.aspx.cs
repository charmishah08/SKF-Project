﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace SKF.Admin
{
    public partial class Stu_EnrollStudent : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";

        protected void Page_Load(object sender, EventArgs e)
        {
           
            if (!IsPostBack)
            {
                BindData();
            }
        }
        public void BindData1()
        {
            sqlstmt = "";
            sqlstmt = "SELECT * FROM enroll_master INNER JOIN class_master ON enroll_master.enroll_class_id = class_master.class_id INNER JOIN class_level_master ON class_master.class_level_id = class_level_master.class_level_id INNER JOIN student_master ON enroll_master.enroll_student_id = student_master.stu_id";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                sqlstmt = "";
                string user_id = ds.Tables[0].Rows[0]["login_id"].ToString();
                //Creting a Cookie Object
                HttpCookie _userInfoCookies = new HttpCookie("userInfo");

                //Setting values inside it
                _userInfoCookies["UserID"] = user_id.ToString();
                _userInfoCookies["Expire"] = "1 Days";
            }
        }
       
        public void BindData()
        {
            sqlstmt = "";
            sqlstmt = "SELECT * FROM enroll_master INNER JOIN class_master ON enroll_master.enroll_class_id = class_master.class_id INNER JOIN class_level_master ON class_master.class_level_id = class_level_master.class_level_id INNER JOIN student_master ON enroll_master.enroll_student_id = student_master.stu_id";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Lst_EnrollStudents.DataSource = ds.Tables[0];
                Lst_EnrollStudents.DataBind();
            }
            else
            {
                Lst_EnrollStudents.DataSource = null;
            }
        }
    }
}
