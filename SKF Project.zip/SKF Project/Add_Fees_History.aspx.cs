﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SKF.Admin
{
    public partial class Add_Fees_History : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindStudent();
                BindClassLevel();
                BindFeesType();
                var unique_id = Request.QueryString["id"];
                if (unique_id != null)
                {
                    GetData();
                }
            }
        }

        public void BindStudent()
        {
            sqlstmt = "";
            sqlstmt = "Select * from student_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropStuName.DataSource = ds.Tables[0];
                DropStuName.DataTextField = "stu_email";
                DropStuName.DataValueField = "stu_id";
                DropStuName.DataBind();
            }
            else
            {
                DropStuName.DataSource = System.DBNull.Value.ToString();
                DropStuName.DataBind();
            }
            DropStuName.Items.Insert(0, "--Select--");
        }

        public void BindClassLevel()
        {
            sqlstmt = "";
            sqlstmt = "Select * from class_level_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropClassLevel.DataSource = ds.Tables[0];
                DropClassLevel.DataTextField = "class_level";
                DropClassLevel.DataValueField = "class_level_id";
                DropClassLevel.DataBind();
            }
            else
            {
                DropClassLevel.DataSource = System.DBNull.Value.ToString();
                DropClassLevel.DataBind();
            }
            DropClassLevel.Items.Insert(0, "--Select--");
        }

        public void BindFeesType()
        {
            sqlstmt = "";
            sqlstmt = "Select * from fees_type_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropFeesType.DataSource = ds.Tables[0];
                DropFeesType.DataTextField = "fees_type_name";
                DropFeesType.DataValueField = "fees_type_id";
                DropFeesType.DataBind();
            }
            else
            {
                DropFeesType.DataSource = System.DBNull.Value.ToString();
                DropFeesType.DataBind();
            }
            DropFeesType.Items.Insert(0, "--Select--");
            DropFeesType.Items.Insert(1, "Other");
        }

        public void GetData()
        {
            var unique_id = Request.QueryString["id"];
            sqlstmt = "";
            sqlstmt = "SELECT * FROM fees_history INNER JOIN fees_master ON fees_history.fees_id = fees_master.fees_id INNER JOIN class_level_master ON fees_master.fees_class_level_id = class_level_master.class_level_id INNER JOIN fees_type_master ON fees_master.fees_type_id = fees_type_master.fees_type_id INNER JOIN student_master ON fees_history.fees_stu_id = student_master.stu_id where fees_history_id = " + unique_id.ToString();
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropStuName.SelectedValue = ds.Tables[0].Rows[0]["fees_stu_id"].ToString();
                int student_id = Convert.ToInt32(ds.Tables[0].Rows[0]["fees_stu_id"].ToString());
                DropClassLevel.SelectedValue = ds.Tables[0].Rows[0]["class_level_id"].ToString();
                DropFeesType.SelectedValue = ds.Tables[0].Rows[0]["fees_type_id"].ToString();
                txtamtpayable.Text = ds.Tables[0].Rows[0]["fees_amount"].ToString();
                txtFeeAmount.Text = ds.Tables[0].Rows[0]["fees_paid"].ToString();
                GetAvailableCredit(student_id);
            }
        }

        public void CrudOP()
        {
            var unique_id = Request.QueryString["id"];
            if (unique_id == null)
            {
                string cdate = System.DateTime.Now.ToString("yyyy-MM-dd");
                sqlstmt = "";
                sqlstmt = "SELECT fees_master.fees_id FROM fees_master WHERE fees_master.fees_class_level_id = " + DropClassLevel.SelectedValue + " AND fees_master.fees_type_id = " + DropFeesType.SelectedValue ;
                DataSet ds = cls.Select(sqlstmt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    string fees_id = ds.Tables[0].Rows[0]["fees_id"].ToString();
                    sqlstmt = "Insert into fees_history (fees_stu_id,fees_id,fees_paid,fees_paid_date) values ('" + DropStuName.SelectedValue + "','" + fees_id.ToString() + "','" + txtFeeAmount.Text.Trim() + "','" + cdate.ToString() + "')";
                    cls.Insert(sqlstmt);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Inserted..!')", true);
                    Response.Redirect("Fees_History.aspx");
                    //ShowMessageBox("Activities.aspx","Record Inserted..!");  
                }  
            }
            else
            {
                string cdate = System.DateTime.Now.ToString("yyyy-MM-dd");
                sqlstmt = "";
                sqlstmt = "SELECT fees_master.fees_id FROM fees_master WHERE fees_master.fees_class_level_id = " + DropClassLevel.SelectedValue + " AND fees_master.fees_type_id = " + DropFeesType.SelectedValue;
                DataSet ds = cls.Select(sqlstmt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    string fees_id = ds.Tables[0].Rows[0]["fees_id"].ToString();
                    sqlstmt = "Update fees_history set fees_id = '" + fees_id.ToString() + "',fees_paid = '" + txtFeeAmount.Text.Trim() + "', fees_paid_date = '" + cdate.ToString() + "' where fees_history_id =" + unique_id.ToString();
                    cls.Update(sqlstmt);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Updated..!')", true);
                    Response.Redirect("Fees_History.aspx");
                    //ShowMessageBox("Activities.aspx", "Record Updated..!");
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            CrudOP();
        }

        protected void DropFeesType_SelectedIndexChanged(object sender, EventArgs e)
        {
            sqlstmt = "";
            sqlstmt = "SELECT fees_amount,fees_master.fees_id FROM fees_master WHERE fees_master.fees_class_level_id = " + DropClassLevel.SelectedValue + " AND fees_master.fees_type_id = " + DropFeesType.SelectedValue;
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                string fees_id = ds.Tables[0].Rows[0]["fees_id"].ToString();
                txtamtpayable.Text = ds.Tables[0].Rows[0]["fees_amount"].ToString();
            }            
        }

        protected void DropStuName_SelectedIndexChanged(object sender, EventArgs e)
        {
            int student_id = Convert.ToInt32(DropStuName.SelectedValue);
            GetAvailableCredit(student_id);
        }
        public void GetAvailableCredit(int stu_id)
        {
            sqlstmt = "";
            sqlstmt = "Select * from student_master where stu_id = " + DropStuName.SelectedValue;
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtAvailableCredit.Text = ds.Tables[0].Rows[0]["stu_available_credit"].ToString();
            }
            else
            {
                txtAvailableCredit.Text = "0.00";
            }
        }
    }
}