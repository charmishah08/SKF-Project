﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SKF.Admin
{
    public partial class Add_Parents : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
                BindStudent();
                BindRelation();
            }

        }

        public void BindStudent()
        {
            sqlstmt = "";
            sqlstmt = "Select * from student_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropStudentName.DataSource = ds.Tables[0];
                DropStudentName.DataTextField = "stu_email";
                DropStudentName.DataValueField = "stu_id";
                DropStudentName.DataBind();
            }
            else
            {
                DropStudentName.DataSource = System.DBNull.Value.ToString();
                DropStudentName.DataBind();
            }
            DropStudentName.Items.Insert(0, "--Select--");
        }

        public void BindRelation()
        {
            sqlstmt = "";
            sqlstmt = "Select * from relation_trans";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Droprelation.DataSource = ds.Tables[0];
                Droprelation.DataTextField = "relation_name";
                Droprelation.DataValueField = "relation_id";
                Droprelation.DataBind();
            }
            else
            {
                Droprelation.DataSource = System.DBNull.Value.ToString();
                Droprelation.DataBind();
            }
            Droprelation.Items.Insert(0, "--Select--");
        }

        public void GetData()
        {
            var unique_id = ViewState["Id"].ToString();
            if (unique_id != null)
            {
                sqlstmt = "";
                sqlstmt = "SELECT * FROM parents_master INNER JOIN student_master ON parents_master.parent_stu_id = student_master.stu_id INNER JOIN relation_trans ON parents_master.parent_relation_id = relation_trans.relation_id WHERE parents_master.parent_id =" + unique_id.ToString();

                DataSet ds = cls.Select(sqlstmt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DropStudentName.SelectedValue = ds.Tables[0].Rows[0]["parent_stu_id"].ToString();
                    Droprelation.SelectedValue = ds.Tables[0].Rows[0]["parent_relation_id"].ToString();
                    txtParentName.Text = ds.Tables[0].Rows[0]["parent_name"].ToString();
                    txtemail.Text = ds.Tables[0].Rows[0]["parent_email"].ToString();
                    txtphone.Text = ds.Tables[0].Rows[0]["parent_phone"].ToString();
                }
            }

        }

        public void BindData()
        {
            sqlstmt = "";
            sqlstmt = "Select * from parents_master";
            System.Data.DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Lst_Parent.DataSource = ds.Tables[0];
                Lst_Parent.DataBind();
            }
            else
            {
                Lst_Parent.DataSource = null;
            }
        }

        public void CrudOP()
        {
            //var unique_id = ViewState["Id"].ToString();
            if (ViewState["Id"] == null)
            {
                sqlstmt = "";
                sqlstmt = "Insert into parents_master (parent_stu_id,parent_relation_id,parent_name,parent_email,parent_phone) values ('" + DropStudentName.SelectedValue.Trim() + "','" + Droprelation.SelectedValue.Trim() + "','" + txtParentName.Text.Trim() + "','" + txtemail.Text.Trim() + "','" + txtphone.Text.Trim() + "')";
                cls.Insert(sqlstmt);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Inserted..!')", true);
                Response.Redirect("Add_Parents.aspx");
                //ShowMessageBox("Activities.aspx","Record Inserted..!");    
            }
            else
            {
                sqlstmt = "";
                sqlstmt = "Update parents_master set parent_stu_id = '" + DropStudentName.SelectedValue.Trim() + "',parent_relation_id = '" + Droprelation.SelectedValue.Trim() + "',parent_name = '" + txtParentName.Text.Trim() + "',parent_email = '" + txtemail.Text.Trim() + "',parent_phone = '" + txtphone.Text.Trim() + "' where parent_id=" + ViewState["Id"].ToString();
                cls.Update(sqlstmt);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Updated..!')", true);
                Response.Redirect("Add_Parents.aspx");
                //ShowMessageBox("Activities.aspx", "Record Updated..!");
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            CrudOP();
        }

        protected void lnkEdit_Click(object sender, EventArgs e)
        {
            LinkButton lnk = (LinkButton)sender;
            ViewState["Id"] = lnk.CommandArgument.ToString();
            GetData();
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            LinkButton lnk = (LinkButton)sender;
            ViewState["Id"] = lnk.CommandArgument.ToString();
            sqlstmt = "";
            sqlstmt = "Delete from parents_master where parent_id=" + ViewState["Id"].ToString();
            cls.Delete(sqlstmt);
            ShowMessageBox();
        }
        private void ShowMessageBox()
        {
            string sJavaScript = "<script language=javascript>\n";
            sJavaScript += "agree = confirm('Record Deleted...'); \n";
            sJavaScript += "if(agree)\n";
            sJavaScript += "window.location = \"Add_Parents.aspx\";\n";
            sJavaScript += "</script>";
            Response.Write(sJavaScript);
        }
    }
}