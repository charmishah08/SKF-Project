﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace SKF.Admin
{
    public partial class Attendance : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindClassLevel();                
            }
        }

      
        public void BindData()
        {
            sqlstmt = "";
            sqlstmt = "SELECT * FROM enroll_master INNER JOIN student_master ON enroll_master.enroll_student_id = student_master.stu_id INNER JOIN class_master ON enroll_master.enroll_class_id = class_master.class_id INNER JOIN class_level_master ON class_master.class_level_id = class_level_master.class_level_id left JOIN attendance_master ON enroll_master.enroll_student_id = attendance_master.attendance_stu_id WHERE class_level_master.class_level_id =" + DropClassLevel.SelectedValue;
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Lst_Designation.Visible = true;
                Lst_Designation.DataSource = ds.Tables[0];
                Lst_Designation.DataBind();
            }
            else
            {
                Lst_Designation.DataSource = null;
                Lst_Designation.Visible = false;
            }
        }

        public void BindClassLevel()
        {
            sqlstmt = "";
            sqlstmt = "Select * from class_level_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropClassLevel.DataSource = ds.Tables[0];
                DropClassLevel.DataTextField = "class_level";
                DropClassLevel.DataValueField = "class_level_id";
                DropClassLevel.DataBind();
            }
            else
            {
                DropClassLevel.DataSource = System.DBNull.Value.ToString();
                DropClassLevel.DataBind();
            }
            DropClassLevel.Items.Insert(0, "--Select--");
        }

        public void CrudOP()
        {
            //var unique_id = ViewState["Id"].ToString();
                sqlstmt = "";
                sqlstmt = "Select * from enroll_master where enroll_id =" + ViewState["Id"].ToString();
                DataSet ds = cls.Select(sqlstmt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    string stu_id = ds.Tables[0].Rows[0]["enroll_student_id"].ToString();
                    string class_id = ds.Tables[0].Rows[0]["enroll_class_id"].ToString();
                    string cdate = System.DateTime.Now.ToString("yyyy-MM-dd");
                    sqlstmt = "";
                    sqlstmt = "Insert into attendance_master (attendance_class_id,attendance_stu_id,attendance_date,attendance_status) values ('" + stu_id.ToString() + "','" + class_id.ToString() + "','" + cdate.ToString() + "','Present')";
                    cls.Insert(sqlstmt);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Inserted..!')", true);
                    Response.Redirect("Attendance.aspx");
                    //ShowMessageBox("Activities.aspx","Record Inserted..!"); 
                }   
        }

        
        protected void lnkEdit_Click(object sender, EventArgs e)
        {
            LinkButton lnk = (LinkButton)sender;
            ViewState["Id"] = lnk.CommandArgument.ToString();
            CrudOP();
        }

        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            LinkButton lnk = (LinkButton)sender;
            ViewState["Id"] = lnk.CommandArgument.ToString();
            sqlstmt = "";
            sqlstmt = "Delete from attendance_master where attendance_id=" + ViewState["Id"].ToString();
            cls.Delete(sqlstmt);
            ShowMessageBox();
        }
        private void ShowMessageBox()
        {
            string sJavaScript = "<script language=javascript>\n";
            sJavaScript += "agree = confirm('Record Deleted...'); \n";
            sJavaScript += "if(agree)\n";
            sJavaScript += "window.location = \"Attendance.aspx\";\n";
            sJavaScript += "</script>";
            Response.Write(sJavaScript);
        }

        protected void DropClassLevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindData();
        }
    }
}