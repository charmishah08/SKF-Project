﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SKF.Admin
{
    public partial class Add_Class_Schedule : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindClassLevel();
                BindInstructor();
                var unique_id = Request.QueryString["id"];
                if (unique_id != null)
                {
                    GetData();
                }
            }
        }
        public void BindClassLevel()
        {
            sqlstmt = "";
            sqlstmt = "Select * from class_level_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropClassLevel.DataSource = ds.Tables[0];
                DropClassLevel.DataTextField = "class_level";
                DropClassLevel.DataValueField = "class_level_id";
                DropClassLevel.DataBind();
            }
            else
            {
                DropClassLevel.DataSource = System.DBNull.Value.ToString();
                DropClassLevel.DataBind();
            }
            DropClassLevel.Items.Insert(0, "--Select--");
        }

        public void BindInstructor()
        {
            sqlstmt = "";
            sqlstmt = "Select * from instructor_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DropInstructor.DataSource = ds.Tables[0];
                DropInstructor.DataTextField = "inst_name";
                DropInstructor.DataValueField = "inst_id";
                DropInstructor.DataBind();
            }
            else
            {
                DropInstructor.DataSource = System.DBNull.Value.ToString();
                DropInstructor.DataBind();
            }
            DropInstructor.Items.Insert(0, "--Select--");
        }
        public void GetData()
        {
            var unique_id = Request.QueryString["id"];
            if (unique_id != null)
            {
                sqlstmt = "";
                sqlstmt = "SELECT * FROM class_master INNER JOIN class_level_master ON class_master.class_level_id = class_level_master.class_level_id INNER JOIN instructor_master ON class_master.class_ins_id = instructor_master.inst_id WHERE class_master.class_id =" + unique_id.ToString();

                DataSet ds = cls.Select(sqlstmt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    DropClassLevel.SelectedValue = ds.Tables[0].Rows[0]["class_level_id"].ToString();
                    DropDays.SelectedValue = ds.Tables[0].Rows[0]["class_days"].ToString();
                    txtStart_time.Text = ds.Tables[0].Rows[0]["class_level_time"].ToString();
                    DropInstructor.SelectedValue = ds.Tables[0].Rows[0]["inst_id"].ToString();
                }
            }

        }

        public void CrudOP()
        {
            var unique_id = Request.QueryString["id"];
            if (unique_id == null)
            {
                sqlstmt = "";
                sqlstmt = "Insert into class_master (class_level_id,class_days,class_level_time,class_ins_id) values ('" + DropClassLevel.SelectedValue.Trim() + "','" + DropDays.SelectedValue.Trim() + "','" + txtStart_time.Text.Trim() + "','" + DropInstructor.SelectedValue.Trim() + "')";
                cls.Insert(sqlstmt);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Inserted..!')", true);
                Response.Redirect("Class_Schedule.aspx");
                //ShowMessageBox("Activities.aspx","Record Inserted..!");    
            }
            else
            {
                sqlstmt = "";
                sqlstmt = "Update class_master set class_level_id = '" + DropClassLevel.SelectedValue.Trim() + "', class_days = '" + DropDays.SelectedValue.Trim() + "', class_level_time = '" + txtStart_time.Text.Trim() + "', class_ins_id = '" + DropInstructor.SelectedValue.Trim() + "' where class_id = " + unique_id.ToString();
                cls.Update(sqlstmt);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Activity", "alert('Record Updated..!')", true);
                Response.Redirect("Class_Schedule.aspx");
                //ShowMessageBox("Activities.aspx", "Record Updated..!");
            }
        }
        private void ShowMessageBox(string sURL, string mSG)
        {
            string sJavaScript = "<script language=javascript>\n";
            sJavaScript += "agree = confirm(" + mSG + "); \n";
            sJavaScript += "if(agree)\n";
            sJavaScript += "window.location = \"" + sURL + "\";\n";
            sJavaScript += "</script>";
            Response.Write(sJavaScript);
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            CrudOP();
        }
    }
}