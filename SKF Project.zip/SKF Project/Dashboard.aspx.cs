﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SKF.Admin
{
    public partial class Dashboard : System.Web.UI.Page
    {
        Connect cls = new Connect();
        string sqlstmt = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Bindstudents();
                Bindactivities();
                Bindranks();
            }
        }

        public void Bindstudents()
        {
            sqlstmt = "";
            sqlstmt = "SELECT Count(student_master.stu_id) AS stucnt FROM student_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                studentcount.Text = ds.Tables[0].Rows[0]["stucnt"].ToString();
            }
        }
        public void Bindranks()
        {
            sqlstmt = "";
            sqlstmt = "SELECT Count(rank_type_master.rank_type_id) AS rnkcnt FROM rank_type_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                rankcount.Text = ds.Tables[0].Rows[0]["rnkcnt"].ToString();
            }
        }
        public void Bindactivities()
        {
            sqlstmt = "";
            sqlstmt = "SELECT Count(activity_master.activity_id) AS actcnt FROM activity_master";
            DataSet ds = cls.Select(sqlstmt);
            if (ds.Tables[0].Rows.Count > 0)
            {
                classcount.Text = ds.Tables[0].Rows[0]["actcnt"].ToString();
            }
        }

    }
}